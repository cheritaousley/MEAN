var math = require('./mathlib')();    
console.log(math);
console.log(math.add(2,3));
console.log(math.multiply(3,5));
console.log(math.square(5));
console.log(math.random(1,35));